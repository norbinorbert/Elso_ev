/*Boda Norbert
511-es csoport*/

#include <iostream>

using namespace std;

#define minimum(a,b) ((a<b)?a:b)
#define maximum(a,b) ((a>b)?a:b)

int main() {
	cout << minimum(2, 3) << " " << maximum(1, 3);
	return 0;
}