//Boda Norbert, 511-es csoport
#include <iostream>
void init(double, double);
void felsz();
void duplaz();
void kiir();

int main() {
	init(1, 3);
	kiir();
	//std::cout << intervallum[0];
	duplaz();
	kiir();
	felsz();
	return 0;
}