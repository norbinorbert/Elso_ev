#!/bin/bash
#
#Boda Norbert, bnim2219
#L05_06
#
#A paraméterekként megadott állományokban szereplő minden nagybetűtől különböző karaktert cserélejen ki az első paraméterként megadott karakterre. A paraméterek sorrendje: karakter állományn(év/evek).

#megnezi ha van-e parameter megadva
if [ $# -lt 2 ]
then
        echo -e "Helytelen parameterezes!\nHasznalat: $0 karakter filenev [filenev ...]"
        exit 1
fi

#megnezi ha az elso parameter egy karakter
if [ ${#1} -gt 1 ]
then
	echo "$1 nem egy karakter"
	exit 1
fi

#segedvaltozoba menti a megadott karaktert
karakter=$1
shift 1

#minden parameter eseten megnezi, ha letezik es ha file, illetve ha mindketto igaz akkor
#elvegzi a megfelelo utasitast
for filenev
do
        if [ -e ${filenev} ]
        then
                if [ "`file ${filenev}|cut -d" " -f3`" = 'text' ]
                then
                        sed -i "s/[^A-Z]/${karakter}/g" ${filenev}
                        echo "`basename ${filenev}` modositva"
                else
                        echo "`basename ${filenev}` nem szoveges allomany"
                fi
        else
                echo "`basename ${filenev}` nem letezik"
        fi
done


exit 0

