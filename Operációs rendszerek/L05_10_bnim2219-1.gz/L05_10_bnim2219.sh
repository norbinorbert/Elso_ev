#!/bin/bash
#
#Boda Norbert, bnim2219
#L05_10
#
#A paraméterekként megadott állományok soraiban cserélje fel az első és harmadik szót. A szavak csak betűket tartalmaznak, minden más karaktert elválasztó karakternek tekintünk.

#megnezi ha van-e parameter megadva
if [ $# -lt 1 ]
then
        echo -e "Helytelen parameterezes!\nHasznalat: $0 filenev [filenev ...]"
        exit 1
fi

#minden parameter eseten megnezi, ha letezik es ha file, illetve ha mindketto igaz akkor
#elvegzi a megfelelo utasitast
for filenev
do
        if [ -e ${filenev} ]
        then
                if [ "`file ${filenev}|cut -d" " -f3`" = 'text' ]
                then
			sed -i -E "s/^([^a-zA-Z]*)([a-zA-Z]+)([^a-zA-Z]+)([a-zA-Z]+)([^a-zA-Z]+)([a-zA-Z]+)/\1\6\3\4\5\2/" ${filenev}
                        echo "`basename ${filenev}` modositva"
                else
                        echo "`basename ${filenev}` nem szoveges allomany"
                fi
        else
                echo "`basename ${filenev}` nem letezik"
        fi
done


exit 0
~                       
