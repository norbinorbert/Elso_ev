#!/bin/bash
#
#Boda Norbert, bnim2219
#L05_02
#
#A paraméterekként megadott állomány(ok)ból törölje ki azokat a sorokat, amelyek az első paraméterként megadott szóval kezdődnek. A paraméterek sorrendje: szó állományn(év/evek).

#megnezi ha van-e parameter megadva
if [ $# -lt 2 ]
then
	echo -e "Helytelen parameterezes!\nHasznalat: $0 szo filenev [filenev ...]"
	exit 1
fi

#segedvaltozoba menti a megadott szot
szo="$1"
shift 1

#minden parameter eseten megnezi, ha letezik es ha file, illetve ha mindketto igaz akkor
#elvegzi a megfelelo utasitast
for filenev
do
	if [ -e ${filenev} ]
	then	
		if [ "`file ${filenev}|cut -d" " -f3`" = 'text' ]
		then
			sed -i "/^${szo}/d" ${filenev}
			echo "`basename ${filenev}` modositva"
		else
			echo "`basename ${filenev}` nem szoveges allomany"
		fi
	else
		echo "`basename ${filenev}` nem letezik"
	fi
done


exit 0
