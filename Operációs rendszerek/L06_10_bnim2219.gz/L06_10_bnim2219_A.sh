#!/bin/bash
#
#Boda Norbert, bnim2219
#L06_10_A
#
#A) Határozzuk meg az első paraméterként kapott katalógus alkatalógusainak átlagos méretét, illetve a második paraméterként megadott méretnél nagyobb alkatalógusok nevét és számát. A paraméterként megadott méret kilobyte-ban van megadva. Az eredményt a következőképpen írjuk ki:
#  átlag: [átlag]
#  [alkatalógus]
#  [alkatalógus]
#  ...
#  összesen [n] darab [k] kilobyte-nál nagyobb alkatalógus
#ahol a helykitöltők helyére a megfelelő adatok kerülnek.

#megnezi, hogy biztosan 2 parameter legyen
if [ $# -ne 2 ]
then
	echo -e "Helytelen parameterezes!\nHasznalat: $0 directory number"
	exit 1
fi

#megnezi ha az elso parameter katalogus
if [ ! -d $1 ]
then	
	echo "$1 nem katalogus"
	exit 1
fi

#megnezi ha a masodik parameter szam
[ $2 -eq $2 ] 2>/dev/null
if [ $? -ne 0 ]
then
	echo "$2 nem szam"
	exit 1
fi

#a du parancs segitsegevel a parameterkent megadott katalogusnak az alkatalogusainak a meretet kiirja,
#majd az awk ezeket a sorokat dolgozza fel es atlagot szamol
du --max-depth=1 "$1"|head -n-1|awk 'BEGIN {osszeg=0}
		{osszeg+=$1}
	END {
		atlag=osszeg/FNR;
		printf("atlag: %f\n", atlag);
	}' -

#ugyanugy a du parancs kilistazza a mereteket, majd az awk kiszuri azokat az alkatalogusokat, 
#amelyek megfelelnek a feltetelnek
du --max-depth=1 "$1"|head -n-1|awk -v meret=$2 'BEGIN {db=0}
	($1 > meret) {
		db++;
		alkatalogus_kezdeti_index=index($0,"/");
		printf("%s\n", substr($0, alkatalogus_kezdeti_index+1));
	}
	END {printf("osszesen %d darab %d kilobyte-nal nagyobb alkatalogus\n", db, meret)}' -


exit 0

