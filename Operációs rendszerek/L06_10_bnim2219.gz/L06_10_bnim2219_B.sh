#!/bin/bash
#
#Boda Norbert, bnim2219
#L06_10_B
#
#B) Adott egy állomány, melynek formátuma:
#       diák_felhasználónév tantárgy1 jegy1 tantárgy2 jegy2 ... tantárgyN jegyN
#Asszociatív tömb(ök) használatával írjunk ki statisztikát az alábbi információkkal, a fent megadott formátumú, első paraméterként megadott állományt felhasználva:
#    melyik tantárgyból hány diák vizsgázott - illetve hány diáknak sikerült a vizsgája
#    az összes tantárgyat tekintve melyik jegy hányszor szerepel
#    a második paraméterként megadott tantárgyat tekintve melyik jegy hányszor szerepelt, és melyik jegy szerepelt a legtöbbször (ha több jegyből is ugyanannyi van, akkor a legnagyobb jegyet írjuk ki)

#ellenorzi, hogy 2 parameter legyen
if [ $# -ne 2 ]
then
	echo -e "Helytelen parameterezes!\nHasznalat: $0 filenev tantargy"
	exit 1
fi

#ellenorzi ha az elso parameter letezik
if [ ! -e $1 ]
then
	echo "$1 nem letezik"
	exit 1
fi

#ellenorzi ha az elso parameter allomany
if [ ! -f $1 ]
then
	echo "$1 nem allomany"
	exit 1
fi

#negy asszociativ tombot hasznalva osszegyujti a kello informaciokat es a feldolgozas vegen kiirja ezeket
awk -v tantargy=$2 'BEGIN {}
	{
		for(i=2; i<=NF; i++){
			if(i%2==0){
				vizsgazok_szama[$i]++;
				if($i==tantargy){
					jegyek_t[$(i+1)]++;
				}
			}
			else{
				jegyek[$i]++;
				if($i >= 5){
					sikeres_vizsga[$(i-1)]++;
				}
			}
		}
	}
	END {
		for(i in vizsgazok_szama){
			printf("%s - %d vizsgazo es %d sikeres vizsga\n", i, vizsgazok_szama[i], sikeres_vizsga[i]);
		}
		printf("\nJegyek es elofordulasok szama:\n");
		for(i in jegyek){
			print jegyek[i], "darab", i;
		}
		printf("\nA(z) %s tantargyat tekintve a jegyek es elofordulasok szama:\n", tantargy);
		darabszam=0; maximum=0;
		for(i in jegyek_t){
			if(jegyek_t[i] >= darabszam && i > maximum){
				darabszam = jegyek_t[i];
				maximum = i;
			}
			print jegyek_t[i], "darab", i;
		}
		printf("A legtobbszor szereplo jegy: %s\n", maximum);
	}' $1
	
exit 0
