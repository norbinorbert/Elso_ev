#!/bin/bash
#
#Boda Norbert, bnim2219
#L07_10
#Írjunk felügyelő programot, amely egy "időzített üzeneteket" tartalmazó állományt kap paraméterként. Ennek szerkezete a következő formátumú:
#         [perc]
#         * [max 10 soros szöveg, melynek minden sora a * karakterre kezdődik]
#A script percenként figyelje a rendszeridőt, és amennyiben a percek száma éppen megegyezik a megadott állomány valamelyik bemenetében megadottal, végezzük el az alábbi feladatokat a config állományban található beállítások alapján:
#
#    uzemmod=lassu esetén a többsoros szöveg sorait 5 másodpercenként írjuk ki
#    uzemmod=csendes esetén a szöveget egy kimenet nevű állományhoz adjuk hozzá úgy, hogy az üzenet elé a pontos dátum illetve rendszeridő kerüljön
#    alapértelmezett eset (ha a config állomány bármi mást tartalmaz vagy esetleg nem is létezik): a megfelelő szöveget a képernyőre írjuk ki.
#
#Amikor a script észreveszi, hogy csendes üzemmódból áttértünk valamelyik másik üzemmódba, jelenítsük meg a kimenet nevű állomány tartalmát a képernyőn, majd töröljük a kimenet állományt.
#Megjegyzés: a szöveget a sor elején levő * karakterek nélkül írjuk ki.
#

#megnezi, hogy 1 parameter legyen
if [ $# -ne 1 ]
then
	echo -e "Helytelen parameterezes!\nHasznalat: $0 filenev"
	exit 1
fi

#megnezi ha a parameter letezik
if [ ! -e $1 ]
then
	echo -e "$1 nem letezik"
	exit 1
fi

#megnezi ha a parameter file
if [ ! -f $1 ]
then
	echo -e "$1 nem allomany"
	exit 1
fi

uzemmod=egyeb
#felugyelo program
while true
do
	#megnezi, hogy milyen uzemmodban vagyunk, illetve
    #ha attertunk csendes uzemmodbol akkor kiirja a kimenet allomanyt es kitorli azt
	if [ -f config ]
    then
    	#lassu uzemmod ellenorzese
    	if [ `grep "uzemmod=lassu" config|wc -l 2>/dev/null` -ne 0 ]
        then
       		if [ $uzemmod = csendes ]
            then
            	echo "A kimenet file tartalma:"
                cat kimenet 2>/dev/null
                rm kimenet 2>/dev/null
            fi
            uzemmod=lassu
        #csendes uzemmod ellenorzese
        elif [ `grep "uzemmod=csendes" config|wc -l 2>/dev/null` -ne 0 ]
        then
            uzemmod=csendes
        else
            if [ $uzemmod = csendes ]
            then
                echo "A kimenet file tartalma:"
                cat kimenet 2>/dev/null
                rm kimenet 2>/dev/null
            fi
            uzemmod=egyeb
        fi
    else
        uzemmod=egyeb
    fi

	#amikor a masodperc 0 akkor megnezi a percet
	if [ `date "+%S"` -eq 0 ]
	then
		perc=`date "+%M"`
		#levagja a perc elejerol a 0-as szamjegyet (pl. 01 -> 1)
		if [ `echo $perc|cut -c1` -eq 0 ]
		then
			perc=`echo $perc|cut -c2`
		fi

		#ha nem talal a percre illeszkedo sort akkor var a kovetkezo percig
		if [ `grep -n "^0*$perc$" $1|wc -l` -eq 0 ]
		then
			sleep 1
			continue
		fi

		#megnezi hanyadik sorban van a nekunk kello szoveg
		sor=`grep -n "^0*$perc$" $1|cut -d: -f1`
		((sor++))
		
		#kiirja a sorokat, ha egyeb uzemmodban vagyunk
		if [ $uzemmod = egyeb ]
		then
			while [[ `tail -n +$sor $1|head -n 1` =~ ^\*.* ]]
			do
				tail -n +$sor $1|head -n 1|cut -c 2-
				((sor++))

			done
		fi

		#5 masodpercenkent kiirja a szoveget lassu uzemmodban
		if [ $uzemmod = lassu ]
        then
        	while [[ `tail -n +$sor $1|head -n 1` =~ ^\*.* ]]
            do
            	tail -n +$sor $1|head -n 1|cut -c 2-
				((sor++))
				sleep 5
            done
        fi

		#csendes uzemmodban fileba irja a sorokat, datummal egyutt
		if [ $uzemmod = csendes ]
        then
			date >>kimenet
            while [[ `tail -n +$sor $1|head -n 1` =~ ^\*.* ]]
            do
    	        tail -n +$sor $1|head -n 1|cut -c 2- >>kimenet
				((sor++))
            done
        fi

		sleep 1
	fi
done


