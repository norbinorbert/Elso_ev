/*Boda Norbert, bnim2219
 
 L11_10

 A kliens jelenléti-listákat kérdez le a szervertől. Egy kérésben az aktuális hónap egy napját, két ([hh:mm] formátumú) időpontot, illetve egy csoportnevet (pl. gr521) küld a szervernek, az pedig visszatéríti, hogy a megadott napon a két időpont között kik azok, akik be voltak jelentkezve a megadott csoportból, az eredményt lista formájában adjuk meg [felhasználónév] : [teljes név] párok formájában, ahol soronként csak egy ilyen pár jelenik meg. A kliens az aktuális hónap egy napját, a két időpontot és a csoportnevet paraméterként kapja, ebben a sorrendben.*/

#include <stdio.h>
#include <stdlib.h>
#include "struct.h"
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

int main(){
	int server_olvas, server_ir;
    	FILE* log = fopen("log", "a");
	
	//server fifo letrehozasa
	mkfifo("sz_bnim2219", S_IFIFO|0666);
	server_olvas = open("sz_bnim2219", O_RDONLY);
	
	while(1){
		//adatok kiolvasasa
		keres tmp;
		if(read(server_olvas, &tmp, sizeof(tmp)) <= 0){
			continue;
		}
		//leallasi feltetel
		if(strcmp(tmp.nap, "stop") == 0){
			break;
		}
		//shell command elokeszitese
		char command[100];
		sprintf(command, "./L11_10_bnim2219.sh %s %s %s %s", tmp.nap, tmp.ido1, tmp.ido2, tmp.csoport);
		
		//kliens fifo letrehozasa
		char kliens[25];
		sprintf(kliens, "kl_bnim2219_%d", tmp.pid);
		server_ir = open(kliens, O_WRONLY);
		
		//shell parancs vegrehajtasa
		fprintf(log, "server - %d - shell scriptet elvegeztem\n", getpid());
		fflush(log);
		FILE* pf = popen(command, "r");

		//eredmeny kiirasa a kliens fifoba
		char buf = fgetc(pf);
		while(buf != EOF){
			fprintf(log, "server - %d - irtam a kovetkezo kliensnek: %d - adat: %c\n", getpid(), tmp.pid, buf);
			fflush(log);
			write(server_ir, &buf, sizeof(buf));
			buf = fgetc(pf);
		}
		close(server_ir);
	}
	close(server_olvas);
	unlink("sz_bnim2219");
	return 0;
}
