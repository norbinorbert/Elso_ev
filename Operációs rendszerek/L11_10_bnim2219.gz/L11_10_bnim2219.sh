#!/bin/bash

#Boda Norbert, bnim2219
# 
# L11_10
#
# A kliens jelenléti-listákat kérdez le a szervertől. Egy kérésben az aktuális hónap egy napját, két ([hh:mm] formátumú) időpontot, illetve egy csoportnevet (pl. gr521) küld a szervernek, az pedig visszatéríti, hogy a megadott napon a két időpont között kik azok, akik be voltak jelentkezve a megadott csoportból, az eredményt lista formájában adjuk meg [felhasználónév] : [teljes név] párok formájában, ahol soronként csak egy ilyen pár jelenik meg. A kliens az aktuális hónap egy napját, a két időpontot és a csoportnevet paraméterként kapja, ebben a sorrendben.

nap=$1

if [ ${#nap} -eq 1 ]
then
	nap=0$1
fi

for i in $(last -s 2023-`date "+%m"`-${nap}$2 -t 2023-`date "+%m"`-${nap}$3 -w| cut -d\  -f1 | head -n-2 | sort | uniq)
do
	if [ `id $i|grep "$4" -|wc -l` -ne 0 ]
	then
		echo "$i : `grep $i /etc/pseudopasswd|cut -d: -f5`"
	fi
done

exit 0

