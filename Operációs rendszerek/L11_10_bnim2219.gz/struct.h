/*Boda Norbert, bnim2219
 
 L11_10

 A kliens jelenléti-listákat kérdez le a szervertől. Egy kérésben az aktuális hónap egy napját, két ([hh:mm] formátumú) időpontot, illetve egy csoportnevet (pl. gr521) küld a szervernek, az pedig visszatéríti, hogy a megadott napon a két időpont között kik azok, akik be voltak jelentkezve a megadott csoportból, az eredményt lista formájában adjuk meg [felhasználónév] : [teljes név] párok formájában, ahol soronként csak egy ilyen pár jelenik meg. A kliens az aktuális hónap egy napját, a két időpontot és a csoportnevet paraméterként kapja, ebben a sorrendben.*/

typedef struct{
	char nap[4];
	char ido1[10];
	char ido2[10];
	char csoport[15];
	int pid;
} keres;
