/*Boda Norbert, bnim2219
 
 L11_10

 A kliens jelenléti-listákat kérdez le a szervertől. Egy kérésben az aktuális hónap egy napját, két ([hh:mm] formátumú) időpontot, illetve egy csoportnevet (pl. gr521) küld a szervernek, az pedig visszatéríti, hogy a megadott napon a két időpont között kik azok, akik be voltak jelentkezve a megadott csoportból, az eredményt lista formájában adjuk meg [felhasználónév] : [teljes név] párok formájában, ahol soronként csak egy ilyen pár jelenik meg. A kliens az aktuális hónap egy napját, a két időpontot és a csoportnevet paraméterként kapja, ebben a sorrendben.*/

#include <stdio.h>
#include <stdlib.h>
#include "struct.h"
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>
#include <fcntl.h>
#include <stdbool.h>

int main(int argc, char* argv[]){
	if(argc!=5 && argc!=2){
		printf("Helytelen parameterszam\nHasznalat: %s nap hh:mm hh:mm csoport\n", argv[0]);
		return 1;
	}
	if(argc==2 && strcmp(argv[1], "stop")){
		printf("Helytelen parameter\nHasznalat: %s stop\n", argv[0]);
		return 1;
	}
	keres tmp;
	//4 parameter eseten bemasolja az adatokat a strukturaba
	if(argc==5){
		strcpy(tmp.nap, argv[1]);
		strcpy(tmp.ido1, argv[2]);
    		strcpy(tmp.ido2, argv[3]);
		strcpy(tmp.csoport, argv[4]);
		tmp.pid = getpid();
	}
	else{
		//1 parameter eseten csak a stop szoveget masolja at
		strcpy(tmp.nap, argv[1]);
	}
	int kliens_olvas, kliens_write;
	FILE* log = fopen("log", "a");
	
	//kliens fifo letrehozasa
	char kliens[25];
	sprintf(kliens, "kl_bnim2219_%d", getpid());
	mkfifo(kliens, S_IFIFO|0666);

	//server fifo megnyitasa irasra
	kliens_write = open("sz_bnim2219", O_WRONLY);
	
	//keres elkuldese
	fprintf(log, "kliens - %d - kerest kuldtem a servernek\n", getpid());
	fflush(log);
	write(kliens_write, &tmp, sizeof(tmp));
	
	if(argc==2){
		unlink(kliens);
		return 0;
	}

	//valasz kiolvasasa es kepernyore irasa az azonositoval egyutt
	char buf;
	kliens_olvas = open(kliens, O_RDONLY);
	fprintf(log, "kliens - %d - valaszt olvastam\n", getpid());
	fflush(log);
	bool ujsor = true;
	while(read(kliens_olvas, &buf, sizeof(buf))){
		if(ujsor){
			printf("%d: ", getpid());
			ujsor = false;
		}
		if(buf == '\n'){
			ujsor = true;
		}	
		printf("%c", buf);
	}

	//fifo bezarasa
	close(kliens_olvas);
	unlink(kliens);
	return 0;
}
