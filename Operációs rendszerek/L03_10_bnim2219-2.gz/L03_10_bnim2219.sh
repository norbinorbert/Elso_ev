#!/bin/bash

#Boda Norbert, bnim2219
#L03_10
#Írjon shell script-et, amely paraméterként egy állománynévből és egy k számból álló párokat kap. Minden ilyen párra írja ki 

#    az állomány nevét, a k számot és
#    amennyiben az állománynak több, mint k sora van, az állomány első k sorát
#    amennyiben az állománynak kevesebb, mint k sora van, akkor minden sorból az első k karaktert

#Minden állomány listázása esetén írjuk ki előbb, hogy mit csinálunk, és a rendszeridőt is:
#[filename] [k]
#elso [k] sor listazasa [ora:perc:masodperc]
#[sorok]
#vagy
#[filename] [k]
#soronkent az elso [k] karakter listazasa [ora:perc:masodperc]
#[karakterek]
#ahol a [filename] helyére a paraméterként megadott állománynevek, a [k] helyére a paraméterként megadott számok, míg az [ora:perc:masodperc] helyére a művelet végrehajtásának rendszerideje (a megadott formátumban), a [sorok], illetve [karakterek] helyére az állományok megfelelő sorai és karakterei kerüljenek.
#Az olvashatóság kedvéért két állományra vonatkozó kiírás közé tegyünk egy elválasztó sort a következő módon:
#------------------------------

#vizsgalja ha paros szamu a parameterszam
if [ ! $(( $# % 2 )) -eq 0 ] || [ $# -eq 0 ]
then 
	echo -e "Nem megfelelo a parameterszam!\nHasznalat: $0 file nr [file nr...]"
	exit 1
fi

#addig hajtja vegig az utasitasokat amig elfogynak a parameterek
while ( [ $# -gt 0 ] )
do
	#megnezi ha a parameter allomany
	if [ ! -f "$1" ]
	then 
		echo "`basename "$1"` nem allomany!"
		shift 2
		if [ ! $# -eq 0 ]
		then
			 echo "------------------------------"
		fi
		continue
	fi

	#megnezi ha a parameter szam
	[ $2 -eq $2 ] 2>/dev/null
	if [ $? -ne 0 ]
	then 
		echo "$2 nem szam!"
		shift 2
		if [ ! $# -eq 0 ]
                then 
			echo "------------------------------"
                fi
		continue
	fi

	echo -e "`basename "$1"` $2"

	megfelelo_hossz=1

	#megnezi minden sorra, ha megvan a k hosszusaga vagy sem
	IFS=$'\n'
	for sor in $(head -n$2 "$1")
	do 
		if [ ${#sor} -gt $2 ]
		then
			megfelelo_hossz=0
		fi	
	done
	unset IFS

	#vegrehajtja a feladat altal kert utasitasokat
	if [ ${megfelelo_hossz} = 1 ]
	then
		echo elso $2 sor listazasa `date +%H:%M:%S`
		head -n$2 "$1"	
	else
		echo soronkent az elso $2 karakter listazasa `date +%H:%M:%S`
		head -n$2 "$1" | cut -c-$2
	fi

	shift 2
	if [ ! $# -eq 0 ]
        then 
		echo "------------------------------"
        fi
done

exit 0













