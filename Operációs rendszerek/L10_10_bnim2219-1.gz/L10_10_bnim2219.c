/*Boda Norbert, bnim2219

  L10_10

  A kliens egy kulcsszót küld a szervernek, amelyet az input nevű állományból olvas. A szerver pedig visszatéríti a kliensnek a kézikönyv (man) leírásokból azokat, amelyek a megadott kulcsszót tartalmazzák (lásd apropos parancs), és felhasználói parancsokra vonatkoznak.*/


#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>

#define max_hossz 1024

int main(){
	FILE* in;
	//ellenorzes, ha letezik-e input allomany
	if(!(in=fopen("input", "r"))){
		fprintf(stderr, "Hiba input megnyitasakor\n");
		return 1;
	}

	//pipeok letrehozasa
	int pipe1[2], pipe2[2];
	if(pipe(pipe1) < 0 || pipe(pipe2) < 0){
		perror("pipe hiba");
		return 1;
	}

	//server folyamat letrehozasa
	switch(fork()){
		case -1: perror("fork hiba");
		case 0:{
			//folosleges pipeok bezarasa
			close(pipe1[1]);
			close(pipe2[0]);

			//informacio kiolvasasa a pipebol
			char szo[max_hossz];
		   	read(pipe1[0], szo, sizeof(szo));
			close(pipe1[0]);

			//vegrehajtani kivant program nevenek letrehozasa
			char program[] = "./L10_10_bnim2219.sh ";
			strcat(program, szo);

			//popen megnyitasa
			FILE* pf;
            pf = popen(program, "r");
			
			//olvasas a popen-bol, illetve pipe-ba iras
			char c = fgetc(pf);
			while(c != EOF){
				write(pipe2[1], &c, sizeof(char));
				c = fgetc(pf);
			}

			//pipe bezarasa es pclose
			pclose(pf);
			close(pipe2[1]);
			return 0;
		}
	}
	
	//kliens folyamat
	
	//folosleges pipeok bezarasa
	close(pipe1[0]);
	close(pipe2[1]);

	//informacio beolvasasa a filebol
	char szo[max_hossz];
	fgets(szo, max_hossz, in);

	//informacio kuldese pipeon keresztul
	write(pipe1[1], szo, sizeof(szo));
	close(pipe1[0]);

	//informacio kiolvasasa a pipebol es kiirasa a kepernyore
	char c;
	while( read(pipe2[0], &c, sizeof(char)) > 0 ){
		printf("%c", c);
	}

	//pipe es file bezarasa
	close(pipe2[0]);
	fclose(in);
	return 0;
}
