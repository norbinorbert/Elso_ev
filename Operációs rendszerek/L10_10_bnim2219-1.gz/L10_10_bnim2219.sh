#!/bin/bash

#Boda Norbert, bnim2219
#L10_10
#
#A kliens egy kulcsszót küld a szervernek, amelyet az input nevű állományból olvas. A szerver pedig visszatéríti a kliensnek a kézikönyv (man) leírásokból azokat, amelyek a megadott kulcsszót tartalmazzák (lásd apropos parancs), és felhasználói parancsokra vonatkoznak.

apropos -e -s 1 $1 2>/dev/null | uniq
