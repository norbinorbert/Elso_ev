#!/bin/bash

#Boda Norbert, bnim2219
#L04_5

#Írassa ki a paraméterként megadott parancsot végrehajtó felhasználók azonosítóját.
#Az eredményt lista formájában írjuk ki a képernyőre, a következő formában:
#[user1]
#[user2]
#...
#[userN]
#ahol a [user] helyett a megfelelő felhasználóneveket jelenítsük meg.

#megnezi ha helyes a parameterszam
if [ $# -eq 0 ] || [ $# -gt 1 ]
then
	echo -e "Helytelen parameterszam!\nMegfelelo hasznalat: $0 parancsnev"
	exit 1
fi

#a feladat altal kert parancs vegrehajtasa
ps -eo user:25,command | grep "$1$" - | cut -d\  -f1| sort | uniq

exit 0

