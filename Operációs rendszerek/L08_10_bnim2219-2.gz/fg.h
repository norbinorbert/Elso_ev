/*Boda Norbert, bnim2219

L08_10

Írjunk egy segit(A, n, m, i, k) függvényt, amelyik az A=(aij, i=1, ..., n, k=1, ..., m) mátrix i. sorában és k. oszlopában levő elem helyére a 0 értéktől különböző szomszédainak (8 szomszéd) számtani középarányosát írja, ha ez az elem 0. Ezt a függvényt használjuk egy B mátrix minden 0 értékű elemének módosítására. A B mátrix elemei valósak és legyen minden 0 elemének legalább két 0 értéktől különböző szomszédja. A mátrixot az input nevű állományból olvassuk be, az eredményt, a behelyettesített mátrixot, pedig az output nevű állományba írjuk.*/

void segit(double**, int, int, int, int);
