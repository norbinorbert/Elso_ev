/*Boda Norbert, bnim2219

L08_10

Írjunk egy segit(A, n, m, i, k) függvényt, amelyik az A=(aij, i=1, ..., n, k=1, ..., m) mátrix i. sorában és k. oszlopában levő elem helyére a 0 értéktől különböző szomszédainak (8 szomszéd) számtani középarányosát írja, ha ez az elem 0. Ezt a függvényt használjuk egy B mátrix minden 0 értékű elemének módosítására. A B mátrix elemei valósak és legyen minden 0 elemének legalább két 0 értéktől különböző szomszédja. A mátrixot az input nevű állományból olvassuk be, az eredményt, a behelyettesített mátrixot, pedig az output nevű állományba írjuk.*/

void segit(double** A, int n, int m, int i, int k){
	if(A[i][k] == 0){
		double osszeg=0;
		int db=0;
		if(i - 1 >= 0 && k - 1 >= 0){
			if(A[i-1][k-1] != 0){
				osszeg += A[i-1][k-1]; 
				db++;
			}
		}
		if(i - 1 >= 0){
			if(A[i-1][k] != 0){
                osszeg += A[i-1][k]; 
                db++;
            }
		}
		if(i - 1 >= 0 && k + 1 < m){
			if(A[i-1][k+1] != 0){
				osszeg += A[i-1][k+1];
				db++;
			}
		}
		if(k - 1 >= 0){
			if(A[i][k-1] != 0){
				osszeg += A[i][k-1]; 
				db++;
			}
		}
		if(k + 1 < m){
			if(A[i][k+1] != 0){
				osszeg += A[i][k+1]; db++;
			}
		}
		if(i + 1 < n && k - 1 >= 0){
			if(A[i+1][k-1] != 0){
				osszeg += A[i+1][k-1]; 
				db++;
			}
		}
		if(i + 1 < n){
			if(A[i+1][k] != 0){
				osszeg += A[i+1][k];
			   	db++;
			}
		}
		if(i + 1 < n && k + 1 < m){
			if(A[i+1][k+1] != 0){
			   	osszeg += A[i+1][k+1]; 
				db++;
			}
		}
		double atlag = osszeg / db;
		A[i][k] = atlag;
	}
}





