/*Boda Norbert, bnim2219

L08_10

Írjunk egy segit(A, n, m, i, k) függvényt, amelyik az A=(aij, i=1, ..., n, k=1, ..., m) mátrix i. sorában és k. oszlopában levő elem helyére a 0 értéktől különböző szomszédainak (8 szomszéd) számtani középarányosát írja, ha ez az elem 0. Ezt a függvényt használjuk egy B mátrix minden 0 értékű elemének módosítására. A B mátrix elemei valósak és legyen minden 0 elemének legalább két 0 értéktől különböző szomszédja. A mátrixot az input nevű állományból olvassuk be, az eredményt, a behelyettesített mátrixot, pedig az output nevű állományba írjuk.*/

#include <stdio.h>
#include <stdlib.h>
#include "fg.h"

int main(){
	FILE* in;
    if(!(in = fopen("input", "r"))){
		fprintf(stderr, "Hiba az input file megnyitasakor\n");
		return 1;
	}
	FILE* out = fopen("output", "w");

	int n, m;
	fscanf(in, "%d %d", &n, &m);
	
	double** A = (double**)malloc(n*sizeof(double*));
	double** B = (double**)malloc(n*sizeof(double*));
	for(int i = 0; i < n; i++){
		A[i] = (double*)malloc(m*sizeof(double));
		B[i] = (double*)malloc(m*sizeof(double));
	}
   	
	for(int i = 0; i < n; i++){
        for(int k = 0; k < m; k++){
        	double tmp;
			fscanf(in, "%lf", &tmp);
			A[i][k] = B[i][k] = tmp;
		}       
	}

	for(int i = 0; i < n; i++){
		for(int k = 0; k < m; k++){
			if(A[i][k] == 0){
				segit(A, n, m, i, k);
				B[i][k] = A[i][k];
				A[i][k] = 0;
			}
		}
	}

	for(int i = 0; i < n; i++){
    	for(int k = 0; k < m; k++){
       		fprintf(out, "%lf ", B[i][k]);
    	}
		fprintf(out, "\n");
    }

	for(int i = 0; i < n; i++){
		free(A[i]);
		free(B[i]);
	}
	free(A);
	free(B);

	fclose(in);
	fclose(out);
	return 0;
}

