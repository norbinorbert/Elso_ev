/* Boda Norbert, bnim2219
 
   L12_10

   Adott egy állomány, amely n2 darab 0 vagy 1 értéket tartalmaz, és egy nxn méretű pályát jelképez, ahol a 0 érték szabad utat, az 1 pedig falat jelöl (Megjegyzés: a pálya szélén sehol nincs fal!). Írjunk programot, mely paraméterként kapja, hogy közönséges vagy falbontó autó viselkedését szimulálja-e. Minden egyes autó-folyamat véletlenszerűen generálja a kezdeti pozícióját (bárhol, a pálya szélén), illetve haladási irányát, majd lépésenként generálja az autó útját (véletlenszerűen generálja, hogy irányt változtat-e vagy sem, és megpróbál a következő pozícióba lépni), mindaddig, amíg a kiinduló pozíciójához képest megérkezik a pálya szemközti oldalára. A közönséges autó nem tud továbbmenni, ha falba ütközik (irányt kell változtasson), ezzel szemben a falbontó autó 0 értékre állítja az 1 értéket. Minden egyes autó írja ki minden lépésben a tartózkodási helyét, illetve menetirányát, a falbontó autó pedig külön jelezze a módosítást. Az állomány megfelelő részeinek zárolásával gondoskodjunk róla, hogy az autók össze ne ütközzenek. Az munkaállomány a matrix.bin nevet viseli, amelyet a matrix nevű szöveges állományból állítunk elő. Futtatható állomány elnevezése: p. Az autó típusát paraméterként adjuk meg, amelyet a következő két kulcsszó jelöl: kozonseges és falbonto.*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#include <stdbool.h>

int main(int argc, char* argv[]){
	//parameter ellenorzes
	if(argc != 2){
		fprintf(stderr, "Helytelen parameterezes!\nHasznalat: %s [kozonseges/falbonto]\n", argv[0]);
		return 1;
	}
	if(strcmp(argv[1], "kozonseges") != 0 && strcmp(argv[1], "falbonto") != 0){
		fprintf(stderr, "A parameter \"falbonto\" vagy \"kozonseges\" kell, hogy legyen!\n");
		return 1;
	}
	bool falbonto = false;
	if(strcmp(argv[1], "falbonto") == 0){
		falbonto = true;
	}
	
	//binaris allomany megnyitasa
	int bin = open("matrix.bin", O_RDWR);
	if(bin < 0){
		fprintf(stderr, "Nem sikerult megnyitni a \"matrix.bin\" allomanyt!\n");
		return 1;
	}

	//log es output allomany megnyitasa
	FILE* log = fopen("log", "a");
	FILE* output = fopen("output", "a");

	//veletlen szam generator elinditasa
	srandom(getpid());

	//matrix meretenek a beolvasasa
	int n;
	read(bin, &n, sizeof(int));

	//lock inicializalasa, mindig 1 int hosszusagu mezot lockolunk
	struct flock lock;
	memset(&lock, 0, sizeof(struct flock));
    lock.l_type=F_WRLCK;
    lock.l_whence=SEEK_SET;
    lock.l_len=sizeof(int);

	//addig general poziciokat amig a palya szelen lesz az auto es mas auto nincs mar ott
	int sor = random() % n, oszlop = random() % n;
	while(1){
		while (sor != 0 && sor != n-1 && oszlop != 0 && oszlop != n-1){
			sor = random() % n;
			oszlop = random() % n;
		}
		int offset = (sor * n + oszlop)*sizeof(int);
		lock.l_start=offset;
		//csak akkor ervenyes a pozicio ha nincs ott auto
		if(fcntl(bin, F_SETLK, &lock) >= 0){
			break;
		}
	}
	int k_sor = sor, k_oszlop = oszlop;

	int iteraciok = 0;
	while(1){
		//max 100 iteraciot fog elvegezni
		if(iteraciok == 100){
			fprintf(log, "[%d] Elertem a 100 iteraciot, folyamat megallitva\n", getpid());
			fflush(log);
			break;
		}
		iteraciok++;
	
		//0 = fel; 1 = jobb; 2 = le; 3 = bal
		int irany = random() % 4;
		int offset = (1 + sor * n + oszlop)*sizeof(int);

		//lepesek szimulalasa
		
		//fel
		if(irany==0){
			fprintf(log, "[%d] Pozicio: %d, %d. Irany: fel\n", getpid(), sor, oszlop);
        	fflush(log);
			if(sor!=0){
				int prev_offset = offset;
				offset-=n*sizeof(int);
				lseek(bin, offset, SEEK_SET);
				int fal=-1;
				read(bin, &fal, sizeof(int)); //megnezi ha van fal azon a helyen ahova szeretne lepni
				if(fal==0 || (fal==1 && falbonto)){
					lock.l_start = offset;
					lock.l_type = F_WRLCK;
					//megprobalja lockolni azt a teruletet, ahova lepni akar
					fprintf(log, "[%d] Zarolni probalom a poziciot ahova lepni akarok\n", getpid());
					int msg = fcntl(bin, F_SETLK, &lock);
					if(msg < 0){
						//ha mar van ott auto akkor nem csinal semmit
						fprintf(log, "[%d] Zarolas sikertelen, mar van ott auto\n", getpid());
					}
					else{
						//ha sikeresen lockolt akkor unlockolja az elozo poziciot
						sor--;
						fprintf(log, "[%d] Zarolas sikeres, unlockolom az elozo poziciomat\n", getpid());
						lock.l_start = prev_offset;
						lock.l_type = F_UNLCK;
						fcntl(bin, F_SETLK, &lock);
						//ha falbonto es falra lepett akkor azt lebontja
						if(falbonto && fal==1){
							fprintf(log, "[%d] %d, %d pozicion falat bontottam\n", getpid(), sor, oszlop); 
							lseek(bin, offset, SEEK_SET);
							int nulla = 0;
							write(bin, &nulla, sizeof(int));
						}
					}
				}
			}
		}

		//jobb
		if(irany==1){
			fprintf(log, "[%d] Pozicio: %d, %d. Irany: jobb\n", getpid(), sor, oszlop);
            fflush(log);
			if(oszlop!=n-1){
				int prev_offset=offset;
				offset+=sizeof(int);
				lseek(bin, offset, SEEK_SET);
				int fal=-1;
                read(bin, &fal, sizeof(int));
                if(fal==0 || (fal==1 && falbonto)){
					lock.l_start = offset;
                    lock.l_type = F_WRLCK;
                    fprintf(log, "[%d] Zarolni probalom a poziciot ahova lepni akarok\n", getpid());
                    int msg = fcntl(bin, F_SETLK, &lock);
                    if(msg < 0){
                        fprintf(log, "[%d] Zarolas sikertelen, mar van ott auto\n", getpid());
                    }
                    else{
                        oszlop++;
                        fprintf(log, "[%d] Zarolas sikeres, unlockolom az elozo poziciomat\n", getpid());
                        lock.l_start = prev_offset;
                        lock.l_type = F_UNLCK;
                        fcntl(bin, F_SETLK, &lock);
                        if(falbonto && fal==1){
                            fprintf(log, "[%d] %d, %d pozicion falat bontottam\n", getpid(), sor, oszlop);
                            lseek(bin, offset, SEEK_SET);
                            int nulla = 0;
                            write(bin, &nulla, sizeof(int));
                        }
                    }
				}
			}
		}

		//le
		if(irany==2){
			fprintf(log, "[%d] Pozicio: %d, %d. Irany: le\n", getpid(), sor, oszlop);
            fflush(log);
			if(sor!=n-1){
				int prev_offset = offset;
				offset+=n*sizeof(int);
				lseek(bin, offset, SEEK_SET);
            	int fal=-1;
                read(bin, &fal, sizeof(int));
                if(fal==0 || (fal==1 && falbonto)){
					lock.l_start = offset;
                    lock.l_type = F_WRLCK;
                    fprintf(log, "[%d] Zarolni probalom a poziciot ahova lepni akarok\n", getpid());
                    int msg = fcntl(bin, F_SETLK, &lock);
                    if(msg < 0){
                        fprintf(log, "[%d] Zarolas sikertelen, mar van ott auto\n", getpid());
                    }
                    else{
                        sor++;
                        fprintf(log, "[%d] Zarolas sikeres, unlockolom az elozo poziciomat\n", getpid());
                        lock.l_start = prev_offset;
                        lock.l_type = F_UNLCK;
                        fcntl(bin, F_SETLK, &lock);
                        if(falbonto && fal==1){
                            fprintf(log, "[%d] %d, %d pozicion falat bontottam\n", getpid(), sor, oszlop);
                            lseek(bin, offset, SEEK_SET);
                            int nulla = 0;
                            write(bin, &nulla, sizeof(int));
                        }
                    }

				}
			}
        }

		//bal
		if(irany==3){
    		fprintf(log, "[%d] Pozicio: %d, %d. Irany: bal\n", getpid(), sor, oszlop);
            fflush(log);
			if(oszlop!=0){
				int prev_offset = offset;
				offset-=sizeof(int);
				lseek(bin, offset, SEEK_SET);
				int fal=-1;
                read(bin, &fal, sizeof(int));
                if(fal==0 || (fal==1 && falbonto)){
					lock.l_start = offset;
                    lock.l_type = F_WRLCK;
                    fprintf(log, "[%d] Zarolni probalom a poziciot ahova lepni akarok\n", getpid());
                    int msg = fcntl(bin, F_SETLK, &lock);
                    if(msg < 0){
                        fprintf(log, "[%d] Zarolas sikertelen, mar van ott auto\n", getpid());
                    }
                    else{
                        oszlop--;
                        fprintf(log, "[%d] Zarolas sikeres, unlockolom az elozo poziciomat\n", getpid());
                        lock.l_start = prev_offset;
                        lock.l_type = F_UNLCK;
                        fcntl(bin, F_SETLK, &lock);
                        if(falbonto && fal==1){
                            fprintf(log, "[%d] %d, %d pozicion falat bontottam\n", getpid(), sor, oszlop);
                            lseek(bin, offset, SEEK_SET);
                            int nulla = 0;
                            write(bin, &nulla, sizeof(int));
                        }
                    }

				}
			}
        }

		//ellenorzes, ha az auto eljutott a masik oldalra
		if((k_sor==0 && sor==n-1) || (k_sor==n-1 && sor==0) || (k_oszlop==0 && oszlop==n-1) || (k_oszlop==n-1 && oszlop==0)){
			fprintf(output, "[%d] Az auto eljutott a palya masik oldalara\nKezdeti pozicio:%d,%d. Vegso: %d,%d\n", getpid(), k_sor, k_oszlop, sor, oszlop);
			fflush(output);
			break;
		}

		sleep(1);
	}

	fclose(log);
	fclose(output);
	close(bin);
	return 0;
}
