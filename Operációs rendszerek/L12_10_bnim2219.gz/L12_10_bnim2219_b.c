/* Boda Norbert, bnim2219
 
   L12_10

   Adott egy állomány, amely n2 darab 0 vagy 1 értéket tartalmaz, és egy nxn méretű pályát jelképez, ahol a 0 érték szabad utat, az 1 pedig falat jelöl (Megjegyzés: a pálya szélén sehol nincs fal!). Írjunk programot, mely paraméterként kapja, hogy közönséges vagy falbontó autó viselkedését szimulálja-e. Minden egyes autó-folyamat véletlenszerűen generálja a kezdeti pozícióját (bárhol, a pálya szélén), illetve haladási irányát, majd lépésenként generálja az autó útját (véletlenszerűen generálja, hogy irányt változtat-e vagy sem, és megpróbál a következő pozícióba lépni), mindaddig, amíg a kiinduló pozíciójához képest megérkezik a pálya szemközti oldalára. A közönséges autó nem tud továbbmenni, ha falba ütközik (irányt kell változtasson), ezzel szemben a falbontó autó 0 értékre állítja az 1 értéket. Minden egyes autó írja ki minden lépésben a tartózkodási helyét, illetve menetirányát, a falbontó autó pedig külön jelezze a módosítást. Az állomány megfelelő részeinek zárolásával gondoskodjunk róla, hogy az autók össze ne ütközzenek. Az munkaállomány a matrix.bin nevet viseli, amelyet a matrix nevű szöveges állományból állítunk elő. Futtatható állomány elnevezése: p. Az autó típusát paraméterként adjuk meg, amelyet a következő két kulcsszó jelöl: kozonseges és falbonto.*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main(){
	//binaris allomany megnyitasa
	int bin = open("matrix.bin", O_WRONLY | O_CREAT, 0644);
	if(bin < 0){
		fprintf(stderr, "Hiba a binaris allomany letrehozasakor\n");
		return 1;
	}

	//bemeneti allomany megnyitasa
	FILE* szoveges = fopen("matrix", "r");
	if(!szoveges){
		fprintf(stderr, "Hiba a matrix allomany megnyitasakor\n");
		return 1;
	}
	
	//binaris allomany feltoltese
	int szam, n;
	fscanf(szoveges, "%d", &n);
	write(bin, &n, sizeof(int));

	for(int i = 0; i < n * n; i++){
		fscanf(szoveges, "%d", &szam);	
		write(bin, &szam, sizeof(int));
	}
	close(bin);
	fclose(szoveges);
	return 0;
}
