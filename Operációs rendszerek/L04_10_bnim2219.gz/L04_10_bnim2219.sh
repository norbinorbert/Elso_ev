#!/bin/bash

#Boda Norbert, bnim2219
#L04_10

#Írassa ki a paraméterként megadott felhasználó(k)ról, hogy a bejelentkezési katalógusuk tartalma mások számára kilistázható-e vagy sem. FIGYELEM! Természetesen csak a létező felhasználóneveket vegyük figyelembe, a nemlétezőkre is írjunk ki megfelelő üzenetet.
#Az eredményt a következő formában írjuk ki:
#[user1] - [listazhato/nem listazhato]
#[dklghskdjg] - nem letezik
#[user2] - [listazhato/nem listazhato]
#ahol a [user] helyett a megfelelő felhasznónevet, [listazhato/nem listazhato] helyére pedig a bejelentkezési katalógusra vonatkozó megfelelő információt írjuk.


#megnezi ha helyes a parameterszam
if [ $# -eq 0 ]
then
	echo -e "Helytelen parameterszam!\nMegfelelo hasznalat: $0 felhasznalonev [felhasznalonev ...]"
	exit 1
fi

#addig hajtja vegig a parancsokat amig elfogynak a parameterek
while ([ ! $# -eq 0 ]) 
do
	#megnezi ha a parameter egy felhasznalo vagy sem
	id $1 >/dev/null 2>/dev/null
	if [ ! $? -eq 0 ]
	then
		echo "$1 - nem letezik"
		shift 1
		continue
	fi
	
	#eredmeny kiirasa
	katalogus=`grep "$1" /etc/pseudopasswd | cut -d: -f6`
	ls ${katalogus} &>/dev/null
	if [ $? -eq 0 ]
	then
		echo "$1 - listazhato"
	else
		echo "$1 - nem listazhato"
	fi	
	shift 1
done

exit 0
