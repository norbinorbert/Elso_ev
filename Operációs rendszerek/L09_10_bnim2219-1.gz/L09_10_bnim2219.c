/*Boda Norbert, bnim2219

  L09_10

  Írjunk programot, amelyik kiszámítja, minél kevesebb műveletet végezve, egy x szám n. hatványát két gyerekfolyamatot használva: egyik kiszámítja (ismételten, amennyiben szükséges) két szám szorzatát, a másik négyzetre emel egy számot (szintén ismételten). x értékét és az n számot parancssorban paraméterként adjuk meg. Összesen 3 folyamat kell legyen, 1 szülő és 2 gyerek. Az eredményt a szülőfolyamat írja ki az output nevű állományba. A könnyebb ellenőrizhetőség kedvéért minden folyamat írja ki a folyamatazonosítóját és az éppen kiszámolt részeredményt a log nevű állományba a Megjegyzések részben szereplő mintának megfelelően.*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>

int main(int argc, char** argv){
	//parameterek helyessegenek ellenorzese
	if(argc != 3){
		fprintf(stderr, "Helytelen parameterezes! Hasznalat: %s szam szam\n", argv[0]);
		return 1;
	}
	for(int i = 1; i <= 2; i++){
		if(!isdigit(*argv[i])){
			fprintf(stderr, "%s nem szam\n", argv[i]);
			return 1;
		}
	}
	int x = 0, n = 0;
  	x = atoi(argv[1]);
	n = atoi(argv[2]);

	//kimeneti fileok megnyitasa
	FILE* out = fopen("output", "w");
	FILE* log = fopen("log", "w");

	//pipeok letrehozasa; 
	//pfd1 - szulo es az elso gyerek kozti kommunikacio
	//pfd2 - szulo es a masodik gyerek kozti kommunikacio
	//pfd12 - a ket gyerek kozti kommunikacio
	int pfd1[2], pfd2[2], pfd12[2];
	if(pipe(pfd1) < 0 || pipe(pfd2) < 0 || pipe(pfd12) < 0){
		perror("Pipe hiba");
		return 1;
	}

	// az elso gyerek letrehozasa, aki ket szamot fog osszeszorozni
	pid_t pid1 = fork();
	if(pid1==-1){
		perror("fork hiba");
		return 1;
	} 
	else if(pid1==0){
		//folosleges pipeok bezarasa
		close(pfd1[1]);
		close(pfd2[0]);
		close(pfd2[1]);
		close(pfd12[0]);
		
		int hatvany, eredmeny, alap;
		while(1){
			//adatok kiolvasasa
			if(read(pfd1[0], &hatvany, sizeof(int)) <= 0){
					break;
			}
			fprintf(log, "gyerek1 - %d - kiolvastam: %d\n", getpid(), hatvany);
    	    fflush(log);

			read(pfd1[0], &eredmeny, sizeof(int));
			fprintf(log, "gyerek1 - %d - kiolvastam: %d\n", getpid(), eredmeny);
    	    fflush(log);
	
			read(pfd1[0], &alap, sizeof(int));
	        fprintf(log, "gyerek1 - %d - kiolvastam: %d\n", getpid(), alap);
    	    fflush(log);
			
			//szorzas elvegzese
			if(hatvany % 2 == 1){
				eredmeny *= alap;
			}

			//adatok beirasa
			fprintf(log, "gyerek1 - %d - beirtam: %d\n", getpid(), hatvany);
	        fflush(log);
			write(pfd12[1], &hatvany, sizeof(int));
		
			fprintf(log, "gyerek1 - %d - beirtam: %d\n", getpid(), eredmeny);
           	fflush(log);
			write(pfd12[1], &eredmeny, sizeof(int));

			fprintf(log, "gyerek1 - %d - beirtam: %d\n", getpid(), alap);
		    fflush(log);
        	write(pfd12[1], &alap, sizeof(int));
		}
		//maradek pipe bezarasa
		close(pfd1[0]);
		close(pfd12[1]);		
		return 0;
	} 
	else{
		//masodik gyerek letrehozasa aki negyzetre emel egy szamot
		pid_t pid2 = fork();
		if(pid2==-1){
			perror("fork hiba");
			return 1;
		} 
		else if (pid2 == 0){
			//folosleges pipeok bezarasa
			close(pfd1[1]);
			close(pfd1[0]);
			close(pfd2[0]);
			close(pfd12[1]);

			int hatvany, eredmeny, alap;
        	while(1){
				//adatok kiolvasasa
				if(read(pfd12[0], &hatvany, sizeof(int)) <=0){
						break;
				}
        		fprintf(log, "gyerek2 - %d - kiolvastam: %d\n", getpid(), hatvany);
	        	fflush(log);

		        read(pfd12[0], &eredmeny, sizeof(int));
    		    fprintf(log, "gyerek2 - %d - kiolvastam: %d\n", getpid(), eredmeny);
        		fflush(log);

		        read(pfd12[0], &alap, sizeof(int));
    		    fprintf(log, "gyerek2 - %d - kiolvastam: %d\n", getpid(), alap);
        		fflush(log);

    			//szorzas elvegzese    
	        	alap *= alap;
				//gyorhatvanyozas eseten minden iteracioban kell a hatvanykitevot osztani kettovel
		        hatvany /= 2;
			
				//adatok beirasa
    	    	fprintf(log, "gyerek2 - %d - beirtam: %d\n", getpid(), hatvany);
                fflush(log);
				write(pfd2[1], &hatvany, sizeof(int));
    
        		fprintf(log, "gyerek2 - %d - beirtam: %d\n", getpid(), eredmeny);
                fflush(log);
				write(pfd2[1], &eredmeny, sizeof(int));
	
    		    fprintf(log, "gyerek2 - %d - beirtam: %d\n", getpid(), alap);
                fflush(log);
				write(pfd2[1], &alap, sizeof(int));
			}
			//maradek pipe bezarasa
            close(pfd12[0]);
		   	close(pfd2[1]);
			return 0;
		}
	   	else {
			//szulo folyamat
			
			//folosleges pipeok bezarasa
			close(pfd1[0]);
			close(pfd2[1]);
			close(pfd12[0]);
			close(pfd12[1]);
			
			int eredmeny = 1, alap = x, hatvany = n;
			while( n > 0 ){
				//adatok beirasa
				fprintf(log, "szulo - %d - beirtam: %d\n", getpid(), hatvany);
                fflush(log);
				write(pfd1[1], &hatvany, sizeof(int));
				
				fprintf(log, "szulo - %d - beirtam: %d\n", getpid(), eredmeny);
                fflush(log);
				write(pfd1[1], &eredmeny, sizeof(int));

            	fprintf(log, "szulo - %d - beirtam: %d\n", getpid(), alap);
                fflush(log);
				write(pfd1[1], &alap, sizeof(int));

				//adatok kiolvasasa
                read(pfd2[0], &hatvany, sizeof(int));
                fprintf(log, "szulo - %d - kiolvastam: %d\n", getpid(), hatvany);
                fflush(log);

                read(pfd2[0], &eredmeny, sizeof(int));
                fprintf(log, "szulo - %d - kiolvastam: %d\n", getpid(), eredmeny);
                fflush(log);

                read(pfd2[0], &alap, sizeof(int));
                fprintf(log, "szulo - %d - kiolvastam: %d\n", getpid(), alap);
                fflush(log);
				n = hatvany;
			}
			
			//maradek pipe bezarasa
			close(pfd2[0]);
			close(pfd1[1]);

			//eredmeny kiirasa
			fprintf(log, "szulo - %d - eredmenyt irtam\n", getpid());
			fprintf(out, "%d\n", eredmeny);

			fclose(out);
			fclose(log);
			return 0;	
		}
	}
}
